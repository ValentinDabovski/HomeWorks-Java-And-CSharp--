﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_08_Isosceles_Triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("   \u00A9   ");
            Console.WriteLine("  \u00A9 \u00A9  ");
            Console.WriteLine(" \u00A9   \u00A9 ");
            Console.WriteLine("\u00A9 \u00A9 \u00A9 \u00A9");
        }
    }
}
