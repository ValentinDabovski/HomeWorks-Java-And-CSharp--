﻿using System;



class Program
{
    static void Main(string[] args)
    {
        double number01 = 34.567839023d;
        float number02 = 12.345f;
        double number03 = 8923.1234857d;
        float number04 = 3456.091f;

        Console.WriteLine(number01);
        Console.WriteLine(number02);
        Console.WriteLine(number03);
        Console.WriteLine(number04);

    }
}

