﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem06_Strings_and_Objects
{
    class QuotesInStrings
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The \"use\" of quotations causes difficulties.");
            Console.WriteLine(@"The ""use"" of quotations causes difficulties.");
        }
    }
}
