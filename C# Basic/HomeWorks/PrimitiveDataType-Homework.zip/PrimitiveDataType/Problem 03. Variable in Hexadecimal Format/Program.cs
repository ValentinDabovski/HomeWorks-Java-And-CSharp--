﻿using System;


class Program
{
    static void Main(string[] args)
    {
        short hex = 0xFE;

        Console.WriteLine(hex);
    }
}

