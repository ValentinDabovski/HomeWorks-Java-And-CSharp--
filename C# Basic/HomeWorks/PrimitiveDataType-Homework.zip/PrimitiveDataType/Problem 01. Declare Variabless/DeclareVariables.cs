﻿using System;

class DeclareVariables
{
    static void Main(string[] args)
    {
        ushort number01 = 52130;
        sbyte number02 = -115;
        sbyte number03 = 97;
        short number04 = -10000;

        Console.WriteLine(number01);
        Console.WriteLine(number02);
        Console.WriteLine(number03);
        Console.WriteLine(number04); 




    }
}

